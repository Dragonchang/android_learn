/** Automatically generated file. DO NOT MODIFY */
package com.htc.systemui.simulator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}