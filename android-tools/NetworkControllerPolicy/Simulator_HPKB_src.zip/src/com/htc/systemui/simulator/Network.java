package com.htc.systemui.simulator;

public class Network {

    public final static String[] SERVICE_STATE = { "IN_SERVICE",
            "OUT_OF_SERVICE", "EMERGENCY_ONLY", "POWER_OFF" };

    public final static String[] NETWORK_TYPE_GSM = { "UNKNOWN:0", "GPRS:1",
            "EDGE:2", "UMTS:3", "HSDPA:8", "HSUPA:9", "HSPA:10", "iDEN:11",
            "LTE:13", "HSPAP:15" };

    public final static String[] NETWORK_TYPE_CDMA = { "UNKNOWN:0", "CDMA:4",
            "EVDO_0:5", "EVDO_A:6", "1xRTT:7", "EVDO_B:12", "LTE:13",
            "eHRPD:14" };

    public final static String[] DATA_STATE = { "DISCONNECTED", "CONNECTING",
            "CONNECTED", "SUSPENDED" };

    public final static String[] DATA_ACTIVITY = { "NONE", "IN", "OUT",
            "IN_OUT", "DORMANT" };

    public final static String[] ERI_INDICATOR = { "ON", "OFF", "FLASH" };

    public final static String[] SIM_STATE = { "ABSENT", "NETWORK_LOCKED",
            "PIN_REQUIRED", "PUK_REQUIRED", "READY", "UNKNOWN" };

    public final static String[] PHONE_TYPE = { "GSM", "CDMA" };

    public final static String[] CALL_STATE = { "IDLE", "RINGING", "OFFHOOK" };

}
