package com.htc.systemui.simulator;

public class ProjectFlag {

    /**
     * Please append new project flag.
     */
    public static final String PROJECT_Airtel_flag = "PROJECT_A0001_flag";
    public static final String PROJECT_Asia_flag = "PROJECT_A0002_flag";
    public static final String PROJECT_ATT_flag = "PROJECT_A0003_flag";
    public static final String PROJECT_AUS_flag = "PROJECT_A0004_flag";
    public static final String PROJECT_ACG_flag = "PROJECT_A0005_flag";
    public static final String PROJECT_Alltel_flag = "PROJECT_A0006_flag";
    public static final String PROJECT_Atick_flag = "PROJECT_A0007_flag";
    public static final String PROJECT_APTG_flag = "PROJECT_A0008_flag";
    public static final String PROJECT_AMX_flag = "PROJECT_A0009_flag";
    public static final String PROJECT_Bouygues_flag = "PROJECT_B0001_flag";
    public static final String PROJECT_BrightStar_flag = "PROJECT_B0002_flag";
    public static final String PROJECT_Bell_flag = "PROJECT_B0003_flag";
    public static final String PROJECT_BM_flag = "PROJECT_B0004_flag";
    public static final String PROJECT_Boost_flag = "PROJECT_B0005_flag";
    public static final String PROJECT_BrightPoint_flag = "PROJECT_B0006_flag";
    public static final String PROJECT_CHT_flag = "PROJECT_C0001_flag";
    public static final String PROJECT_ChungHwa_flag = "PROJECT_C0002_flag";
    public static final String PROJECT_CSL_flag = "PROJECT_C0003_flag";
    public static final String PROJECT_Claro_flag = "PROJECT_C0004_flag";
    public static final String PROJECT_CellSouth_flag = "PROJECT_C0005_flag";
    public static final String PROJECT_ClearWire_flag = "PROJECT_C0006_flag";
    public static final String PROJECT_COS_flag = "PROJECT_C0007_flag";
    public static final String PROJECT_CU_flag = "PROJECT_C0008_flag";
    public static final String PROJECT_CT_flag = "PROJECT_C0009_flag";
    public static final String PROJECT_CMCC_flag = "PROJECT_C0010_flag";
    public static final String PROJECT_CBW_flag = "PROJECT_C0011_flag";
    public static final String PROJECT_CricketUS_flag = "PROJECT_C0012_flag";
    public static final String PROJECT_DE3G_flag = "PROJECT_D0001_flag";
    public static final String PROJECT_Designer_flag = "PROJECT_D0002_flag";
    public static final String PROJECT_DoCoMo_flag = "PROJECT_D0003_flag";
    public static final String PROJECT_Dopod_flag = "PROJECT_D0004_flag";
    public static final String PROJECT_Digitel_flag = "PROJECT_D0005_flag";
    public static final String PROJECT_DTAC_flag = "PROJECT_D0006_flag";
    public static final String PROJECT_Dave_flag = "PROJECT_D0007_flag";
    public static final String PROJECT_EU_flag = "PROJECT_E0001_flag";
    public static final String PROJECT_Etisalat_flag = "PROJECT_E0002_flag";
    public static final String PROJECT_Entel_flag = "PROJECT_E0003_flag";
    public static final String PROJECT_eMMC_flag = "PROJECT_E0004_flag";
    public static final String PROJECT_Egypt_flag = "PROJECT_E0005_flag";
    public static final String PROJECT_eMobile_flag = "PROJECT_E0006_flag";
    public static final String PROJECT_ENT_flag = "PROJECT_E0007_flag";
    public static final String PROJECT_Fastweb_flag = "PROJECT_F0001_flag";
    public static final String PROJECT_FET_flag = "PROJECT_F0002_flag";
    public static final String PROJECT_FHL_flag = "PROJECT_F0003_flag";
    public static final String PROJECT_GCC_flag = "PROJECT_G0007_flag";
    public static final String PROJECT_Generic_flag = "PROJECT_G0001_flag";
    public static final String PROJECT_GMS_flag = "PROJECT_G0006_flag";
    public static final String PROJECT_GWS_flag = "PROJECT_G0009_flag";
    public static final String PROJECT_Globalive_flag = "PROJECT_G0008_flag";
    public static final String PROJECT_H3G_flag = "PROJECT_G0002_flag";
    public static final String PROJECT_HK_flag = "PROJECT_G0003_flag";
    public static final String PROJECT_HKSG_flag = "PROJECT_G0004_flag";
    public static final String PROJECT_HTC_flag = "PROJECT_G0005_flag";
    public static final String PROJECT_Hutch_flag = "PROJECT_H0001_flag";
    public static final String PROJECT_Iusacell_flag = "PROJECT_I0001_flag";
    public static final String PROJECT_KT_flag = "PROJECT_K0001_flag";
    public static final String PROJECT_KDDI_flag = "PROJECT_K0002_flag";
    public static final String PROJECT_Laputa_flag = "PROJECT_L0001_flag";
    public static final String PROJECT_LPM_flag = "PROJECT_L0002_flag";
    public static final String PROJECT_MEA_flag = "PROJECT_M0001_flag";
    public static final String PROJECT_Movilnet_flag = "PROJECT_M0003_flag";
    public static final String PROJECT_Mobilkom_flag = "PROJECT_M0004_flag";
    public static final String PROJECT_MTN_flag = "PROJECT_M0002_flag";
    public static final String PROJECT_MTS_flag = "PROJECT_M0005_flag";
    public static final String PROJECT_Movistar_flag = "PROJECT_M0006_flag";
    public static final String PROJECT_MetroPCS_flag = "PROJECT_M0007_flag";
    // duplicated, so mark it
    // public static final String PROJECT_Movilnet_flag = "PROJECT_M0008_flag";
    public static final String PROJECT_NewAP_flag = "PROJECT_N0001_flag";
    public static final String PROJECT_NRJ_flag = "PROJECT_N0002_flag";
    public static final String PROJECT_OrangeBE_flag = "PROJECT_O0001_flag";
    public static final String PROJECT_Orange_flag = "PROJECT_O0002_flag";
    public static final String PROJECT_O2_flag = "PROJECT_O0003_flag";
    public static final String PROJECT_Optus_flag = "PROJECT_O0004_flag";
    public static final String PROJECT_OpenSense_flag = "PROJECT_O0005_flag";
    public static final String PROJECT_OpenMobile_flag = "PROJECT_O0006_flag";
    public static final String PROJECT_PTB_flag = "PROJECT_P0001_flag";
    public static final String PROJECT_Personal_flag = "PROJECT_P0002_flag";
    public static final String PROJECT_QMR_flag = "PROJECT_Q0001_flag";
    public static final String PROJECT_Rogers_flag = "PROJECT_R0001_flag";
    public static final String PROJECT_RadioShack_flag = "PROJECT_R0002_flag";
    public static final String PROJECT_SA_flag = "PROJECT_S0001_flag";
    public static final String PROJECT_SEA2G_flag = "PROJECT_S0006_flag";
    public static final String PROJECT_SEA_flag = "PROJECT_S0002_flag";
    public static final String PROJECT_SG_flag = "PROJECT_S0003_flag";
    public static final String PROJECT_SIE_flag = "PROJECT_S0008_flag";
    public static final String PROJECT_SingTel_flag = "PROJECT_S0004_flag";
    public static final String PROJECT_Sprint_flag = "PROJECT_S0005_flag";
    public static final String PROJECT_STC_flag = "PROJECT_S0007_flag";
    public static final String PROJECT_SBM_flag = "PROJECT_S0009_flag";
    public static final String PROJECT_SKT_flag = "PROJECT_S0010_flag";
    public static final String PROJECT_SFN_flag = "PROJECT_S0011_flag";
    public static final String PROJECT_SPA_flag = "PROJECT_S0012_flag";
    public static final String PROJECT_SFR_flag = "PROJECT_S0013_flag";
    public static final String PROJECT_Swisscom_flag = "PROJECT_S0014_flag";
    public static final String PROJECT_Sasktel_flag = "PROJECT_S0015_flag";
    public static final String PROJECT_Solavei_flag = "PROJECT_S0016_flag";
    public static final String PROJECT_Telefonica_flag = "PROJECT_T0007_flag";
    public static final String PROJECT_Telstra_flag = "PROJECT_T0008_flag";
    public static final String PROJECT_Telus_flag = "PROJECT_T0001_flag";
    public static final String PROJECT_Tim_flag = "PROJECT_T0002_flag";
    public static final String PROJECT_TME_flag = "PROJECT_T0003_flag";
    public static final String PROJECT_TMI_flag = "PROJECT_T0009_flag";
    public static final String PROJECT_TMO_flag = "PROJECT_T0004_flag";
    public static final String PROJECT_TWM_flag = "PROJECT_T0006_flag";
    public static final String PROJECT_Tesco_flag = "PROJECT_T0010_flag";
    public static final String PROJECT_Tigo_flag = "PROJECT_T0011_flag";
    public static final String PROJECT_TeleRing_flag = "PROJECT_T0012_flag";
    public static final String PROJECT_Telcel = "PROJECT_T0013_flag";
    public static final String PROJECT_TNZ = "PROJECT_T0014_flag";
    public static final String PROJECT_UKR_flag = "PROJECT_U0001_flag";
    public static final String PROJECT_USC_flag = "PROJECT_U0002_flag";
    public static final String PROJECT_UTSTARCOM_flag = "PROJECT_U0003_flag";
    public static final String PROJECT_Unefon_flag = "PROJECT_U0004_flag";
    public static final String PROJECT_Verizon_flag = "PROJECT_V0001_flag";
    public static final String PROJECT_VodaFone_flag = "PROJECT_V0002_flag";
    public static final String PROJECT_Vodacom_flag = "PROJECT_V0003_flag";
    public static final String PROJECT_VM_flag = "PROJECT_V0004_flag";
    public static final String PROJECT_VHA_flag = "PROJECT_V0005_flag";
    public static final String PROJECT_Videotron_flag = "PROJECT_V0006_flag";
    public static final String PROJECT_Vivo_flag = "PROJECT_V0007_flag";
    public static final String PROJECT_VMUS_flag = "PROJECT_V0008_flag";
    public static final String PROJECT_VMAU_flag = "PROJECT_V0009_flag";
    public static final String PROJECT_Yoigo_flag = "PROJECT_Y0001_flag";
    public static final String PROJECT_ZA_flag = "PROJECT_Z0001_flag";

    /**
     * Please append new project name.
     */
    public static final String[] PROJECT_FLAG = { "Airtel", "Asia", "ATT",
            "AUS", "ACG", "Alltel", "Atick", "APTG", "AMX", "Bouygues",
            "BrightStar", "Bell", "BM", "Boost", "BrightPoint", "CHT",
            "ChungHwa", "CSL", "Claro", "CellSouth", "ClearWire", "COS", "CU",
            "CT", "CMCC", "CBW", "CricketUS", "DE3G", "Designer", "DoCoMo",
            "Dopod", "Digitel", "DTAC", "Dave", "EU", "Etisalat", "Entel",
            "eMMC", "Egypt", "eMobile", "ENT", "Fastweb", "FET", "FHL", "GCC",
            "Generic", "GMS", "GWS", "Globalive", "H3G", "HK", "HKSG", "HTC",
            "Hutch", "Iusacell", "KT", "KDDI", "Laputa", "LPM", "MEA",
            "Movilnet", "Mobilkom", "MTN", "MTS", "Movistar", "MetroPCS",
            "NewAP", "NRJ", "OrangeBE", "Orange", "O2", "Optus", "OpenSense",
            "OpenMobile", "PTB", "Personal", "QMR", "Rogers", "RadioShack",
            "SA", "SEA2G", "SEA", "SG", "SIE", "SingTel", "Sprint", "STC",
            "SBM", "SKT", "SFN", "SPA", "SFR", "Swisscom", "Sasktel",
            "Solavei", "Telefonica", "Telstra", "Telus", "Tim", "TME", "TMI",
            "TMO", "TWM", "Tesco", "Tigo", "TeleRing", "Telcel", "TNZ", "UKR",
            "USC", "UTSTARCOM", "Unefon", "Verizon", "VodaFone", "Vodacom",
            "VM", "VHA", "Videotron", "Vivo", "VMUS", "VMAU", "Yoigo", "ZA" };

}
