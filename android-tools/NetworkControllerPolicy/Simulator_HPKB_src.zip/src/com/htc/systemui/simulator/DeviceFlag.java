package com.htc.systemui.simulator;

public class DeviceFlag {

    /**
     * Please append new device flag if need, thanks.
     */
    public static final String DEVICE_Ace_flag = "DEVICE_A0001_flag";
    public static final String DEVICE_Autobot_flag = "DEVICE_A0002_flag";
    public static final String DEVICE_AceLTE_flag = "DEVICE_A0003_flag";
    public static final String DEVICE_Bahamas_flag = "DEVICE_B0001_flag";
    public static final String DEVICE_Bravo_flag = "DEVICE_B0002_flag";
    public static final String DEVICE_BravoC_flag = "DEVICE_B0003_flag";
    public static final String DEVICE_Bee_flag = "DEVICE_B0004_flag";
    public static final String DEVICE_Buzz_flag = "DEVICE_B0005_flag";
    public static final String DEVICE_BlitzC_flag = "DEVICE_B0006_flag";
    public static final String DEVICE_Bliss_flag = "DEVICE_B0007_flag";
    public static final String DEVICE_BlissC_flag = "DEVICE_B0008_flag";
    public static final String DEVICE_ChaCha_flag = "DEVICE_C0001_flag";
    public static final String DEVICE_CP2DCG_flag = "DEVICE_C0002_flag";
    public static final String DEVICE_CP2DTG_flag = "DEVICE_C0003_flag";
    public static final String DEVICE_CP2DUG_flag = "DEVICE_C0004_flag";
    public static final String DEVICE_DesireC_flag = "DEVICE_D0001_flag";
    public static final String DEVICE_Dragon_flag = "DEVICE_D0002_flag";
    public static final String DEVICE_Dream_flag = "DEVICE_D0003_flag";
    public static final String DEVICE_Dynasty_flag = "DEVICE_D0004_flag";
    public static final String DEVICE_DoubleShot_flag = "DEVICE_D0005_flag";
    public static final String DEVICE_Dlx_flag = "DEVICE_D0006_flag";
    public static final String DEVICE_DlxJ_flag = "DEVICE_D0007_flag";
    public static final String DEVICE_Espresso_flag = "DEVICE_E0001_flag";
    public static final String DEVICE_Express_flag = "DEVICE_E0002_flag";
    public static final String DEVICE_ExpressKT_flag = "DEVICE_E0003_flag";
    public static final String DEVICE_ExpressH_flag = "DEVICE_E0004_flag";
    public static final String DEVICE_Evita_flag = "DEVICE_E0005_flag";
    public static final String DEVICE_EndeavorTD_flag = "DEVICE_E0006_flag";
    public static final String DEVICE_EndeavorU_flag = "DEVICE_E0007_flag";
    public static final String DEVICE_EraU_flag = "DEVICE_E0008_flag";
    public static final String DEVICE_EnrC2U_flag = "DEVICE_E0009_flag";
    public static final String DEVICE_EvitareUL_flag = "DEVICE_E0010_flag";
    public static final String DEVICE_Flyer_flag = "DEVICE_F0001_flag";
    public static final String DEVICE_Fit_flag = "DEVICE_F0002_flag";
    public static final String DEVICE_Fighter_flag = "DEVICE_F0003_flag";
    public static final String DEVICE_Fireball_flag = "DEVICE_F0004_flag";
    public static final String DEVICE_Glacier_flag = "DEVICE_G0001_flag";
    public static final String DEVICE_GolfU_flag = "DEVICE_G0002_flag";
    public static final String DEVICE_Golfc_flag = "DEVICE_G0003_flag";
    public static final String DEVICE_Halo_flag = "DEVICE_H0001_flag";
    public static final String DEVICE_HeroC_flag = "DEVICE_H0003_flag";
    public static final String DEVICE_HeroCT_flag = "DEVICE_H0004_flag";
    public static final String DEVICE_Hero_flag = "DEVICE_H0002_flag";
    public static final String DEVICE_Huangshan_flag = "DEVICE_H0005_flag";
    public static final String DEVICE_Huashan_flag = "DEVICE_H0006_flag";
    public static final String DEVICE_Holiday_flag = "DEVICE_H0007_flag";
    public static final String DEVICE_IncredibleC_flag = "DEVICE_I0001_flag";
    public static final String DEVICE_Icon_flag = "DEVICE_I0002_flag";
    public static final String DEVICE_IconG_flag = "DEVICE_I0003_flag";
    public static final String DEVICE_JET_flag = "DEVICE_J0001_flag";
    public static final String DEVICE_Jewel_flag = "DEVICE_J0002_flag";
    public static final String DEVICE_JelDD_flag = "DEVICE_J0003_flag";
    public static final String DEVICE_Kingdom_flag = "DEVICE_K0001_flag";
    public static final String DEVICE_Knight_flag = "DEVICE_K0003_flag";
    public static final String DEVICE_KingdomU_flag = "DEVICE_K0002_flag";
    public static final String DEVICE_K2WL_flag = "DEVICE_K0004_flag";
    public static final String DEVICE_K2cl_flag = "DEVICE_K0005_flag";
    public static final String DEVICE_Lead_flag = "DEVICE_L0004_flag";
    public static final String DEVICE_Legend_flag = "DEVICE_L0001_flag";
    public static final String DEVICE_Lexikon_flag = "DEVICE_L0003_flag";
    public static final String DEVICE_Liberty_flag = "DEVICE_L0002_flag";
    public static final String DEVICE_LexikonCT_flag = "DEVICE_L0005_flag";
    public static final String DEVICE_Layer_flag = "DEVICE_L0006_flag";
    public static final String DEVICE_Memphis_flag = "DEVICE_M0001_flag";
    public static final String DEVICE_Mecha_flag = "DEVICE_M0002_flag";
    public static final String DEVICE_Marvel_flag = "DEVICE_M0003_flag";
    public static final String DEVICE_MarvelC_flag = "DEVICE_M0004_flag";
    public static final String DEVICE_Monaco_flag = "DEVICE_M0005_flag";
    public static final String DEVICE_OboeA_flag = "DEVICE_O0001_flag";
    public static final String DEVICE_Paradise_flag = "DEVICE_P0001_flag";
    public static final String DEVICE_Passion_flag = "DEVICE_P0002_flag";
    public static final String DEVICE_PassionC_flag = "DEVICE_P0003_flag";
    public static final String DEVICE_Pyramid_flag = "DEVICE_P0004_flag";
    public static final String DEVICE_PucciniLTE_flag = "DEVICE_P0005_flag";
    public static final String DEVICE_PydTD_flag = "DEVICE_P0006_flag";
    public static final String DEVICE_Pico_flag = "DEVICE_P0007_flag";
    public static final String DEVICE_PopC_flag = "DEVICE_P0008_flag";
    public static final String DEVICE_PopCT_flag = "DEVICE_P0009_flag";
    public static final String DEVICE_PROTD_flag = "DEVICE_P0010_flag";
    public static final String DEVICE_PrimoU_flag = "DEVICE_P0011_flag";
    public static final String DEVICE_PrimoC_flag = "DEVICE_P0012_flag";
    public static final String DEVICE_PrimoDS_flag = "DEVICE_P0013_flag";
    public static final String DEVICE_PrimoDD_flag = "DEVICE_P0014_flag";
    public static final String DEVICE_PrimoTD_flag = "DEVICE_P0015_flag";
    public static final String DEVICE_Quattro_flag = "DEVICE_Q0001_flag";
    public static final String DEVICE_Quattrof_flag = "DEVICE_Q0002_flag";
    public static final String DEVICE_Quattrou_flag = "DEVICE_Q0003_flag";
    public static final String DEVICE_Rider_flag = "DEVICE_R0001_flag";
    public static final String DEVICE_Ruby_flag = "DEVICE_R0002_flag";
    public static final String DEVICE_Runnymede_flag = "DEVICE_R0003_flag";
    public static final String DEVICE_Sapphire_flag = "DEVICE_S0001_flag";
    public static final String DEVICE_Songshan_flag = "DEVICE_S0003_flag";
    public static final String DEVICE_Speedy_flag = "DEVICE_S0004_flag";
    public static final String DEVICE_Saga_flag = "DEVICE_S0005_flag";
    public static final String DEVICE_Shooter_flag = "DEVICE_S0006_flag";
    public static final String DEVICE_ShooterU_flag = "DEVICE_S0007_flag";
    public static final String DEVICE_ShooterCT_flag = "DEVICE_S0008_flag";
    public static final String DEVICE_ShooterK_flag = "DEVICE_S0009_flag";
    public static final String DEVICE_Supersonic_flag = "DEVICE_S0002_flag";
    public static final String DEVICE_Tianshan_flag = "DEVICE_T0001_flag";
    public static final String DEVICE_Tango_flag = "DEVICE_T0002_flag";
    public static final String DEVICE_Tube_flag = "DEVICE_T0003_flag";
    public static final String DEVICE_Tag_flag = "DEVICE_T0004_flag";
    public static final String DEVICE_TagU_flag = "DEVICE_T0005_flag";
    public static final String DEVICE_TagH_flag = "DEVICE_T0006_flag";
    public static final String DEVICE_Tahiti_flag = "DEVICE_T0007_flag";
    public static final String DEVICE_Totem_flag = "DEVICE_T0008_flag";
    public static final String DEVICE_Vision_flag = "DEVICE_V0001_flag";
    public static final String DEVICE_Vivo_flag = "DEVICE_V0002_flag";
    public static final String DEVICE_Vivow_flag = "DEVICE_V0003_flag";
    public static final String DEVICE_Verdi_flag = "DEVICE_V0004_flag";
    public static final String DEVICE_VerdiLTE_flag = "DEVICE_V0005_flag";
    public static final String DEVICE_Vigor_flag = "DEVICE_V0006_flag";
    public static final String DEVICE_Velocecx_flag = "DEVICE_V0007_flag";
    public static final String DEVICE_Vertexf_flag = "DEVICE_V0008_flag";
    public static final String DEVICE_Vertexfp_flag = "DEVICE_V0009_flag";
    public static final String DEVICE_Valentewx_flag = "DEVICE_V0010_flag";
    public static final String DEVICE_VivoC_flag = "DEVICE_V0011_flag";
    public static final String DEVICE_VILLE_flag = "DEVICE_V0012_flag";
    public static final String DEVICE_VivowCT_flag = "DEVICE_V0013_flag";
    public static final String DEVICE_VilleC2_flag = "DEVICE_V0014_flag";
    public static final String DEVICE_Valentewxc9_flag = "DEVICE_V0015_flag";

    /**
     * Please append new device name, thanks.
     */
    public static final String[] DEVICE_FLAG = { "Ace", "Autobot", "AceLTE",
            "Bahamas", "Bravo", "BravoC", "Bee", "Buzz", "BlitzC", "Bliss",
            "BlissC", "ChaCha", "CP2DCG", "CP2DTG", "CP2DUG", "DesireC",
            "Dragon", "Dream", "Dynasty", "DoubleShot", "Dlx", "DlxJ",
            "Espresso", "Express", "ExpressKT", "ExpressH", "Evita",
            "EndeavorTD", "EndeavorU", "EraU", "EnrC2U", "EvitareUL", "Flyer",
            "Fit", "Fighter", "Fireball", "Glacier", "GolfU", "Golfc", "Halo",
            "HeroC", "HeroCT", "Hero", "Huangshan", "Huashan", "Holiday",
            "IncredibleC", "Icon", "IconG", "JET", "Jewel", "JelDD", "Kingdom",
            "Knight", "KingdomU", "K2WL", "K2cl", "Lead", "Legend", "Lexikon",
            "Liberty", "LexikonCT", "Layer", "Memphis", "Mecha", "Marvel",
            "MarvelC", "Monaco", "OboeA", "Paradise", "Passion", "PassionC",
            "Pyramid", "PucciniLTE", "PydTD", "Pico", "PopC", "PopCT", "PROTD",
            "PrimoU", "PrimoC", "PrimoDS", "PrimoDD", "PrimoTD", "Quattro",
            "Quattrof", "Quattrou", "Rider", "Ruby", "Runnymede", "Sapphire",
            "Songshan", "Speedy", "Saga", "Shooter", "ShooterU", "ShooterCT",
            "ShooterK", "Supersonic", "Tianshan", "Tango", "Tube", "Tag",
            "TagU", "TagH", "Tahiti", "Totem", "Vision", "Vivo", "Vivow",
            "Verdi", "VerdiLTE", "Vigor", "Velocecx", "Vertexf", "Vertexfp",
            "Valentewx", "VivoC", "VILLE", "VivowCT", "VilleC2", "Valentewxc9" };

}
