package com.htc.systemui.simulator;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Switch;

public class StatedSwitch extends Switch {

    private boolean mState;

    public StatedSwitch(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public StatedSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setState(boolean b) {
        mState = b;
    }

    public boolean getState() {
        return mState;
    }

}