package com.htc.systemui.simulator;

public class LanguageFlag {

    /**
     * Please append new language flag.
     */
    public static final String LANGUAGE_16_flag = "LANGUAGE_16_flag";
    public static final String LANGUAGE_20_flag = "LANGUAGE_20_flag";
    public static final String LANGUAGE_21_flag = "LANGUAGE_21_flag";
    public static final String LANGUAGE_30_flag = "LANGUAGE_30_flag";
    public static final String LANGUAGE_32_flag = "LANGUAGE_32_flag";
    public static final String LANGUAGE_35_flag = "LANGUAGE_35_flag";
    public static final String LANGUAGE_3D_flag = "LANGUAGE_3D_flag";
    public static final String LANGUAGE_40_flag = "LANGUAGE_40_flag";
    public static final String LANGUAGE_45_flag = "LANGUAGE_45_flag";
    public static final String LANGUAGE_ARA_flag = "LANGUAGE_ARA_flag";
    public static final String LANGUAGE_AT_flag = "LANGUAGE_AT_flag";
    public static final String LANGUAGE_AU_flag = "LANGUAGE_AU_flag";
    public static final String LANGUAGE_Alltel_flag = "LANGUAGE_Alltel_flag";
    public static final String LANGUAGE_Appala_flag = "LANGUAGE_Appala_fla";
    public static final String LANGUAGE_BCM_flag = "LANGUAGE_BCM_flag";
    public static final String LANGUAGE_BE_flag = "LANGUAGE_BE_flag";
    public static final String LANGUAGE_Balkan_flag = "LANGUAGE_Balkan_flag";
    public static final String LANGUAGE_Blue_flag = "LANGUAGE_Blue_flag";
    public static final String LANGUAGE_CELL_flag = "LANGUAGE_CELL_flag";
    public static final String LANGUAGE_CHS_flag = "LANGUAGE_CHS_flag";
    public static final String LANGUAGE_CHT_flag = "LANGUAGE_CHT_flag";
    public static final String LANGUAGE_CH_flag = "LANGUAGE_CH_flag";
    public static final String LANGUAGE_COX_flag = "LANGUAGE_COX_flag";
    public static final String LANGUAGE_CU_flag = "LANGUAGE_CU_flag";
    public static final String LANGUAGE_CZ_flag = "LANGUAGE_CZ_flag";
    public static final String LANGUAGE_CellCom_flag = "LANGUAGE_CellCom_flag";
    public static final String LANGUAGE_CellSouth_flag = "LANGUAGE_CellSouth_flag";
    public static final String LANGUAGE_DA_flag = "LANGUAGE_DA_flag";
    public static final String LANGUAGE_DE_flag = "LANGUAGE_DE_flag";
    public static final String LANGUAGE_DualCore_flag = "LANGUAGE_DualCore_flag";
    public static final String LANGUAGE_ES_flag = "LANGUAGE_ES_flag";
    public static final String LANGUAGE_EastEurope_flag = "LANGUAGE_EastEurope_flag";
    public static final String LANGUAGE_FR_flag = "LANGUAGE_FR_flag";
    public static final String LANGUAGE_GER_flag = "LANGUAGE_GER_flag";
    public static final String LANGUAGE_GR_flag = "LANGUAGE_GR_flag";
    public static final String LANGUAGE_HDMI_flag = "LANGUAGE_HDMI_flag";
    public static final String LANGUAGE_IND_flag = "LANGUAGE_IND_flag";
    public static final String LANGUAGE_ISR_flag = "LANGUAGE_ISR_flag";
    public static final String LANGUAGE_ITA_flag = "LANGUAGE_ITA_flag";
    public static final String LANGUAGE_Indonesia_flag = "LANGUAGE_Indonesia_flag";
    public static final String LANGUAGE_Iusacell_flag = "LANGUAGE_Iusacell_flag";
    public static final String LANGUAGE_JAP_flag = "LANGUAGE_JAP_flag";
    public static final String LANGUAGE_Morocco_flag = "Morocco_flag";
    public static final String LANGUAGE_Movilnet_flag = "LANGUAGE_Movilnet_flag";
    public static final String LANGUAGE_NL_flag = "LANGUAGE_NL_flag";
    public static final String LANGUAGE_NZ_flag = "LANGUAGE_NZ_flag";
    public static final String LANGUAGE_NonCIQ_flag = "LANGUAGE_NonCIQ_flag";
    public static final String LANGUAGE_Nordic_flag = "LANGUAGE_Nordic_flag";
    public static final String LANGUAGE_Others_flag = "LANGUAGE_Others_flag";
    public static final String LANGUAGE_PLS_flag = "LANGUAGE_PLS_flag";
    public static final String LANGUAGE_PL_flag = "LANGUAGE_PL_flag";
    public static final String LANGUAGE_PTB_flag = "LANGUAGE_PTB_flag";
    public static final String LANGUAGE_PT_flag = "LANGUAGE_PT_flag";
    public static final String LANGUAGE_RO_flag = "LANGUAGE_RO_flag";
    public static final String LANGUAGE_RUS_flag = "LANGUAGE_RUS_flag";
    public static final String LANGUAGE_RadioShack_flag = "LANGUAGE_RadioShack_flag";
    public static final String LANGUAGE_SPA_flag = "LANGUAGE_SPA_flag";
    public static final String LANGUAGE_Single_flag = "LANGUAGE_Single_flag";
    public static final String LANGUAGE_TH_flag = "LANGUAGE_TH_flag";
    public static final String LANGUAGE_TR_flag = "LANGUAGE_TR_flag";
    public static final String LANGUAGE_TW_flag = "LANGUAGE_TW_flag";
    public static final String LANGUAGE_UKNFC_flag = "LANGUAGE_UKNFC_flag";
    public static final String LANGUAGE_UK_flag = "LANGUAGE_UK_flag";
    public static final String LANGUAGE_WWENFC_flag = "LANGUAGE_WWENFC_flag";
    public static final String LANGUAGE_WWE_flag = "LANGUAGE_WWE_flag";
    public static final String LANGUAGE_ZA_flag = "LANGUAGE_ZA_flag";
    public static final String LANGUAGE_eMMC_flag = "LANGUAGE_eMMC_flag";
    public static final String LANGUAGE_nTelos_flag = "LANGUAGE_nTelos_flag";

    /**
     * Please append new language name.
     */
    public static final String[] LANGUAGE_FLAG = { "16", "20", "21", "30",
            "32", "35", "3D", "40", "45", "ARA", "AT", "AU", "Alltel",
            "Appala", "BCM", "BE", "Balkan", "Blue", "CELL", "CHS", "CHT",
            "CH", "COX", "CU", "CZ", "CellCom", "CellSouth", "DA", "DE",
            "DualCore", "ES", "EastEurope", "FR", "GER", "GR", "HDMI", "IND",
            "ISR", "ITA", "Indonesia", "Iusacell", "JAP", "Morocco",
            "Movilnet", "NL", "NZ", "NonCIQ", "Nordic", "Others", "PLS", "PL",
            "PTB", "PT", "RO", "RUS", "RadioShack", "SPA", "Single", "TH",
            "TR", "TW", "UKNFC", "UK", "WWENFC", "WWE", "ZA", "eMMC", "nTelos" };

}