package com.htc.systemui.simulator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class SystemUISimulator extends Activity {

    /* Simulation */
    private Switch swhSimulation;
    private boolean enableSimulation = true;

    /* Controls */
    private EditText edtSkuId, edtRegion;
    private StatedSwitch swhHasCsService, swhHasPsService, swhAirplaneMode, swhInetCondition, swhLTECA,
        swhShow4gForLTE, swhShow3gForEvdo;
    private Spinner sprPhoneType, sprSimState, sprNetworkType, sprDataState,
            sprDataActivity, sprRoamingCdma, sprCallState;
    private EditText edtCellOperator, edtSimOperator, edtNetworkId, edtSectorId, edtNetworkCountry, edtCellId;
    private StatedSwitch swhRoamingGsm, swhSilentReset;
    private TextView txtSignalStrength;
    private SeekBar skbSignalStrength;
    private View roamingGsmGroup, roamingCdmaGroup;

    /* Listener */
    private ValueChangedListener mValueChangedListener = new ValueChangedListener();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        /* Simulation */
        swhSimulation = (Switch) findViewById(R.id.swhSimulation);
        swhSimulation.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean checked) {
                enableSimulation = checked;
                sendIntent();
                // enable/disable all
                swhAirplaneMode.setEnabled(checked);
                swhHasCsService.setEnabled(checked);
                swhHasPsService.setEnabled(checked);
                sprPhoneType.setEnabled(checked);
                sprSimState.setEnabled(checked);
                sprNetworkType.setEnabled(checked);
                sprCallState.setEnabled(checked);
                sprDataState.setEnabled(checked);
                sprDataActivity.setEnabled(checked);
                edtCellOperator.setEnabled(checked);
                edtSimOperator.setEnabled(checked);
                edtNetworkId.setEnabled(checked);
                edtNetworkCountry.setEnabled(checked);
                edtSectorId.setEnabled(checked);
                edtCellId.setEnabled(checked);
                edtSkuId.setEnabled(checked);
                edtRegion.setEnabled(checked);
                swhSilentReset.setEnabled(checked);
                skbSignalStrength.setEnabled(checked);
                swhInetCondition.setEnabled(checked);
                swhLTECA.setEnabled(checked);
                swhShow4gForLTE.setEnabled(checked);
                swhShow3gForEvdo.setEnabled(checked);
                if (0 == (int) sprPhoneType.getSelectedItemId()) {
                    swhRoamingGsm.setEnabled(checked);
                    roamingGsmGroup.setVisibility(View.VISIBLE);
                    roamingCdmaGroup.setVisibility(View.GONE);
                } else {
                    sprRoamingCdma.setEnabled(checked);
                    roamingGsmGroup.setVisibility(View.GONE);
                    roamingCdmaGroup.setVisibility(View.VISIBLE);
                }
            }
        });

        edtSkuId = (EditText) findViewById(R.id.edtSkuId);
        edtRegion = (EditText) findViewById(R.id.edtRegion);

        sprPhoneType = (Spinner) findViewById(R.id.sprPhoneType);
        final ArrayAdapter<String> adrPhoneType = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, Network.PHONE_TYPE);
        adrPhoneType
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprPhoneType.setAdapter(adrPhoneType);
        sprPhoneType.setSelection(0);
        sprPhoneType.setOnItemSelectedListener(mValueChangedListener);

        sprSimState = (Spinner) findViewById(R.id.sprSimState);
        final ArrayAdapter<String> adrSimState = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, Network.SIM_STATE);
        adrSimState
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprSimState.setAdapter(adrSimState);
        sprSimState.setSelection(5);
        sprSimState.setOnItemSelectedListener(mValueChangedListener);

        sprNetworkType = (Spinner) findViewById(R.id.sprNetworkType);
        final ArrayAdapter<String> adrNetworkType = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item,
                Network.NETWORK_TYPE_GSM);
        adrNetworkType
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprNetworkType.setAdapter(adrNetworkType);
        sprNetworkType.setSelection(6); // set to HSPA by default
        sprNetworkType.setOnItemSelectedListener(mValueChangedListener);

        sprDataState = (Spinner) findViewById(R.id.sprDataState);
        final ArrayAdapter<String> adrDataState = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, Network.DATA_STATE);
        adrDataState
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprDataState.setAdapter(adrDataState);
        sprDataState.setSelection(2);
        sprDataState.setOnItemSelectedListener(mValueChangedListener);

        sprDataActivity = (Spinner) findViewById(R.id.sprDataActivity);
        final ArrayAdapter<String> adrDataActivity = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item,
                Network.DATA_ACTIVITY);
        adrDataActivity
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprDataActivity.setAdapter(adrDataActivity);
        sprDataActivity.setSelection(3);
        sprDataActivity.setOnItemSelectedListener(mValueChangedListener);

        sprRoamingCdma = (Spinner) findViewById(R.id.sprRoamingCdma);
        final ArrayAdapter<String> adrRoamingCdma = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item,
                Network.ERI_INDICATOR);
        adrRoamingCdma
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprRoamingCdma.setAdapter(adrRoamingCdma);
        sprRoamingCdma.setSelection(0);
        sprRoamingCdma.setOnItemSelectedListener(mValueChangedListener);

        sprCallState = (Spinner) findViewById(R.id.sprCallState);
        final ArrayAdapter<String> adrCallState = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item,
                Network.CALL_STATE);
        adrCallState
                .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        sprCallState.setAdapter(adrCallState);
        sprCallState.setOnItemSelectedListener(mValueChangedListener);

        edtCellOperator = (EditText) findViewById(R.id.edtCellOperator);
        edtSimOperator = (EditText) findViewById(R.id.edtSimOperator);

        edtNetworkId = (EditText) findViewById(R.id.edtNetworkId);

        edtNetworkCountry = (EditText) findViewById(R.id.edtNetworkCountry);

        edtSectorId = (EditText) findViewById(R.id.edtSectorId);

        edtCellId = (EditText) findViewById(R.id.edtCellId);

        swhAirplaneMode = (StatedSwitch) findViewById(R.id.swhAirplaneMode);
        swhAirplaneMode.setState(false);
        swhAirplaneMode
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        swhHasCsService = (StatedSwitch) findViewById(R.id.swhHasCsService);
        swhHasCsService.setState(true);
        swhHasCsService.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean checked) {
                ((StatedSwitch) arg0).setState(checked);
                sendIntent();
            }
        });

        swhHasPsService = (StatedSwitch) findViewById(R.id.swhHasPsService);
        swhHasPsService.setState(true);
        swhHasPsService.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean checked) {
                ((StatedSwitch) arg0).setState(checked);
                sendIntent();
            }
        });

        swhRoamingGsm = (StatedSwitch) findViewById(R.id.swhRoamingGsm);
        swhRoamingGsm.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean checked) {
                ((StatedSwitch) arg0).setState(checked);
                sendIntent();
            }
        });

        swhSilentReset = (StatedSwitch) findViewById(R.id.swhSilentReset);
        swhSilentReset
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        swhInetCondition = (StatedSwitch) findViewById(R.id.swhInetCondition);
        swhInetCondition
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        swhLTECA = (StatedSwitch) findViewById(R.id.swhLTECA);
        swhLTECA
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        swhShow4gForLTE = (StatedSwitch) findViewById(R.id.swhShow4gForLTE);
        swhShow4gForLTE
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        swhShow3gForEvdo = (StatedSwitch) findViewById(R.id.swhShow3gForEvdo);
        swhShow3gForEvdo
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {
                    public void onCheckedChanged(CompoundButton arg0,
                            boolean checked) {
                        ((StatedSwitch) arg0).setState(checked);
                        sendIntent();
                    }
                });

        roamingGsmGroup = findViewById(R.id.roaming_gsm_group);
        roamingCdmaGroup = findViewById(R.id.roaming_cdma_group);
        roamingCdmaGroup.setVisibility(View.GONE);

        txtSignalStrength = (TextView) findViewById(R.id.txtSignalStrength);
        txtSignalStrength.setText("0");
        skbSignalStrength = (SeekBar) findViewById(R.id.skbSignalStrength);
        skbSignalStrength.setOnSeekBarChangeListener(mValueChangedListener);
    }

    private int mLastPhoneType = 0;

    class ValueChangedListener implements OnSeekBarChangeListener,
            OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                long arg3) {
            sendIntent();

            int phoneType = (int) sprPhoneType.getSelectedItemId();
            if (phoneType != mLastPhoneType) {
                mLastPhoneType = phoneType;
                if (phoneType == 0) {
                    final ArrayAdapter<String> adrNetworkType = new ArrayAdapter<String>(
                            SystemUISimulator.this,
                            android.R.layout.simple_spinner_item,
                            Network.NETWORK_TYPE_GSM);
                    adrNetworkType
                            .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                    sprNetworkType.setAdapter(adrNetworkType);
                    // HSPA by default
                    sprNetworkType.setSelection(6);
                    // hide CDMA roaming option
                    roamingCdmaGroup.setVisibility(View.GONE);
                    roamingGsmGroup.setVisibility(View.VISIBLE);
                } else {
                    final ArrayAdapter<String> adrNetworkType = new ArrayAdapter<String>(
                            SystemUISimulator.this,
                            android.R.layout.simple_spinner_item,
                            Network.NETWORK_TYPE_CDMA);
                    adrNetworkType
                            .setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                    sprNetworkType.setAdapter(adrNetworkType);
                    // EVDO_A by default
                    sprNetworkType.setSelection(3);
                    // hide GSM roaming option
                    roamingCdmaGroup.setVisibility(View.VISIBLE);
                    roamingGsmGroup.setVisibility(View.GONE);
                }
            }
        }

        public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
            txtSignalStrength.setText(String.valueOf(skbSignalStrength.getProgress()));
            sendIntent();
        }

        public void onStopTrackingTouch(SeekBar arg0) {
            sendIntent();
        }

        public void onStartTrackingTouch(SeekBar arg0) {
        }

        public void onNothingSelected(AdapterView<?> arg0) {
        }

    }

    private void sendIntent() {

        final Intent intent = new Intent(
                "com.android.systemui.simulator.action_change");

        intent.putExtra("SIMULATION_ENABLED", enableSimulation);

        if (enableSimulation) {

            // SKU ID
            try {
                intent.putExtra("SIMULATE_SKU_ID",
                        Integer.parseInt(edtSkuId.getText().toString()));
                intent.putExtra("SIMULATE_REGION",
                        Integer.parseInt(edtRegion.getText().toString()));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            // airplane mode
            intent.putExtra("SIMULATE_AIRPLANE_MODE",
                    swhAirplaneMode.getState());

            // has service
            intent.putExtra("SIMULATE_HAS_CS_SERVICE", swhHasCsService.getState());
            intent.putExtra("SIMULATE_HAS_PS_SERVICE", swhHasPsService.getState());

            // phone type
            intent.putExtra("SIMULATE_PHONE_TYPE",
                (int) sprPhoneType.getSelectedItemId());

            // SIM state
            intent.putExtra("SIMULATE_SIM_STATE", sprSimState.getSelectedItem()
                    .toString());

            // network type
            intent.putExtra(
                    "SIMULATE_NETWORK_TYPE",
                    Integer.parseInt(sprNetworkType.getSelectedItem()
                            .toString().split(":")[1]));

            // data state
            intent.putExtra("SIMULATE_DATA_STATE",
                    (int) sprDataState.getSelectedItemId());

            // data activity
            intent.putExtra("SIMULATE_DATA_ACTIVITY",
                    (int) sprDataActivity.getSelectedItemId());

            // signal strength
            intent.putExtra("SIMULATE_SIGNAL_LEVEL",
                    skbSignalStrength.getProgress());

            // Roaming GSM
            intent.putExtra("SIMULATE_NETWORK_ROAMING",
                    swhRoamingGsm.getState() ? 1 : 0);

            // Roaming CDMA
            intent.putExtra("SIMULATE_ERI_INDICATOR",
                    (int) sprRoamingCdma.getSelectedItemId());

            // Call state
            intent.putExtra("SIMULATE_CALL_STATE",
                    (int) sprCallState.getSelectedItemId());

            // Silent reset
            intent.putExtra("SIMULATE_UNDER_SILENT_RESET",
                    swhSilentReset.getState() ? 1 : 0);

            // cell operator
            intent.putExtra("SIMULATE_NETWORK_OPERATOR", edtCellOperator
                    .getText().toString());

            // SIM operator
            intent.putExtra("SIMULATE_SIM_OPERATOR", edtSimOperator
                    .getText().toString());

            // network id
            try {
                intent.putExtra("SIMULATE_NETWORK_ID",
                        Integer.parseInt(edtNetworkId.getText().toString()));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            // country(MCC)
            try {
                intent.putExtra("SIMULATE_NETWORK_COUNTRY",
                        edtNetworkCountry.getText().toString());
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            // sector id
            intent.putExtra("SIMULATE_SECTOR_ID", edtSectorId.getText()
                    .toString());

            // sector id
            intent.putExtra("SIMULATE_CELL_ID", edtCellId.getText()
                    .toString());

            // data inetCondition
            intent.putExtra("SIMULATE_INETCONDITION", swhInetCondition.getState() ? 1 : 0);

            // LTE CA
            intent.putExtra("SIMULATE_LTECA", swhLTECA.getState());
            
            // show 4g for lte
            intent.putExtra("SIMULATE_SHOW_4G_FOR_LTE", swhShow4gForLTE.getState());

            // show 3g for evdo
            intent.putExtra("SIMULATE_SHOW_3G_FOR_EVDO", swhShow3gForEvdo.getState());
        }

        sendBroadcast(intent);
    }
}
